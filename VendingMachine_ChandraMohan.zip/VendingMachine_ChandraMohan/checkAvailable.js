//As of now hardcoded the Quantity and price, if database is available directly we can assign those values to Quantity.
var cola = 5;
var coke = 5;
var pepper = 5;
var sprite = 5;
var fanta = 5;
var ginger = 5;   
var items = [];
var errorMessage = 'Insufficient Amount, Please Insert More Coins.';
var itemErrorMessage = 'Out of Stock. Please refill';
var errorMessageNoCoint = 'Please Insert Coins.';
var available = "Availabity: "

function checkAvailable(event){     
    var coin = parseInt(document.getElementById('coin').value);    
    var item = event.target.id;
    var itemDummy = event.target.id;
    var successMessage = 'Succss  ';
    var balance = 0;   
    if(coin >= event.target.value)
     {   
        switch(item){
            case "cola":
                balance = cola;
                cola = cola - 1;
                break;
            case "coke":
                balance = coke;
                coke = coke - 1;
                break;
            case "pepper":
                balance = pepper;
                pepper = pepper - 1;
                break;
            case "sprite":
                balance = sprite;
                sprite = sprite-1;
                break;
            case "fanta":
                balance = fanta;
                fanta = fanta-1;
                break;
            case "ginger":
                balance = ginger;
                ginger = ginger-1;
                break;
        }
        // Item count
        if(balance > 0){ 
            document.getElementById('coin').value = '';      
            coin = coin-event.target.value;
            successMessage = successMessage  + 'Remaining Balance:' + coin;
            items.push(item);
            document.getElementById('purchaseItmes').innerHTML = "Puchased Items: " + items.join("\n");
            document.getElementById('success').innerHTML = successMessage;
            setTimeout(function () { document.getElementById('success').innerHTML = '';}, 3000);
        }
        else
        {
            itemErrorMessage = item + '-' + itemErrorMessage;
            document.getElementById('error').innerHTML = itemErrorMessage;
            setTimeout(function () { document.getElementById('error').innerHTML = '';}, 3000);
        }
    }
    else
    {
        if(coin){
            document.getElementById('error').innerHTML = errorMessage;
        }
        else
        {
            document.getElementById('error').innerHTML = errorMessageNoCoint;
        }
       
        setTimeout(function () { document.getElementById('error').innerHTML = '';}, 3000);
    }
}